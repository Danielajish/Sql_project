create database restaurant;
create database Sales_Delivery;
use sales_delivery;
select * from market_fact;
# Question 1: Find the top 3 customers who have the maximum number of orders
select * from(select * , dense_rank()over(order by orders desc) rank1 from 
(select cust_id,customer_name, count(ord_id) orders from market_fact
join cust_dimen  using(cust_id) group by cust_id,customer_name)t
)t1
where rank1<= 3;


select customer_name,cust_id,count(ord_id) as no_of_orders from market_fact 
join cust_dimen using(cust_id)group by cust_id,customer_name
order by  no_of_orders desc limit 3;

#q2  Create a new column DaysTakenForDelivery that contains the date difference between Order_Date and Ship_Date.

select order_id,Order_Date,ship_date, datediff(str_to_date(Ship_Date,'%d-%m-%Y'),str_to_date(Order_Date,'%d-%m-%Y'))
 DaysTakenForDelivery from orders_dimen join shipping_dimen using (Order_ID);
 
select * from market_fact;
select * from orders_dimen;
select * from orders_dimen;
select * from shipping_dimen;
#Question 3: Find the customer whose order took the maximum time to get delivered.
select * from 
(select customer_name ,DaysTakenForDelivery, dense_rank()over( order by DaysTakenForDelivery desc ) rank1 from
(select distinct customer_name, cust_id,order_id,Order_Date,ship_date,s.ship_id, datediff(str_to_date(Ship_Date,'%d-%m-%Y'),str_to_date(Order_Date,'%d-%m-%Y'))
 DaysTakenForDelivery from orders_dimen join shipping_dimen s using (Order_ID) join market_fact m using(ord_id) 
 join cust_dimen using(cust_id))t) t 
 where rank1 = 1;
select * from prod_dimen;
select * from market_fact ;
#Question 4: Retrieve total sales made by each product from the data (use Windows function)
select distinct prod_id,sum(sales)over(partition by prod_id)  total_sales from
market_fact ; 
#Question 5: Retrieve the total profit made from each product from the data (use windows function)
select distinct prod_id,sum(profit)over(partition  by prod_id )  total_profit from
market_fact;
#Question 6: Count the total number of unique customers in January and how many of them came back every month over the entire year in 2011
select * from cust_dimen;
select * from market_fact;
select * from orders_dimen;

select count(customer_name) as  total_unique_customers ,mon_purch from
(select distinct customer_name,  month(str_to_date(order_date,'%d-%m-%Y')) mon_purch 
from market_fact m
join orders_dimen o using (ord_id) join cust_dimen using(cust_id)
where (month(str_to_date(order_date,'%d-%m-%Y')) = 1 )  and (year(str_to_date(order_date,'%d-%m-%Y')) = 2011))t
 group by mon_purch ;


select  distinct count(customer_name) from
(select distinct customer_name,  count(distinct month((str_to_date(order_date,'%d-%m-%Y')))) no_of_months 
from market_fact m
join orders_dimen o using (ord_id) join cust_dimen using(cust_id)
where year(str_to_date(order_date,'%d-%m-%Y')) = 2011
group by  customer_name)t
where no_of_months> 12;
# no one has shopped in all 12 months









