
use university1;
create table student_det(
Student_id int, Student_name varchar(20), mail_id varchar(30), mobile_no varchar(11));
create table student_det_backup(
Student_id int, Student_name varchar(20), mail_id varchar(30), mobile_no varchar(11));
create trigger studentupdate1
before delete on student_det
for each row
insert into student_det_backup  (student_id,student_name,mail_id,mobile_no)
VALUES (OLD.student_id, OLD.student_name, OLD.mail_id, OLD.mobile_no);


insert into student_det values(101,'abc','abc@.com','+1234567899'),
(102,'bbc','bbc@.com','+1235567899');
select * from student_det;
select * from student_det_backup;
delete from student_det where student_id = 102;
select * from student_det;
select * from student_det_backup;
insert into student_det values(103,'dbc','dbc@.com','+1234567899');

show triggers;
