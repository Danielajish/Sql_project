use restaurant;
#Question 1: - We need to find out the total visits to all restaurants under all alcohol categories available.
select * from geoplaces2;
select * from rating_final;
select placeid,name,alcohol, count(userid) from geoplaces2 join rating_final using(placeid)
group by placeid,name,alcohol;

select distinct alcohol, count(userid)over(partition by alcohol) from geoplaces2 join rating_final using(placeid)
;

#Question 2: -Let's find out the average rating according to alcohol and price so that we can understand the rating in respective price categories as well.

select alcohol,price,avg(rating) from
(select placeid,alcohol,rating,price
from  geoplaces2  g join rating_final r  using(placeid))t
group by alcohol,price; 

select distinct alcohol,price,avg(rating)over(partition by alcohol , price)
from  geoplaces2  g join rating_final r  using(placeid);
select * from geoplaces2;
select distinct placeid from chefmozparking;

#Question 3:  Let’s write a query to quantify that what are the parking availability as well in different 
#alcohol categories along with the total number of restaurants.

select alcohol,parking_lot, count(placeid) from
(select placeid,alcohol,parking_lot from geoplaces2 g join
chefmozparking c using(placeid)) t 
group by alcohol,parking_lot;

select distinct alcohol,parking_lot , count(placeid)over (partition by alcohol,parking_lot) no_of_restraunts from
(select distinct placeid,alcohol,parking_lot from geoplaces2 g join
chefmozparking c using(placeid)) t;
#Question 4: -Also take out the percentage of different cuisine in each alcohol type.
select * from  chefmozcuisine ;
select * from geoplaces2;
select * from rating_final;
select alcohol,Rcuisine,cnt,cnt2, (cnt/cnt2)*100 as percent from
(select distinct alcohol,Rcuisine,count(rcuisine)over(partition by alcohol,rcuisine
order by alcohol) cnt ,count(rcuisine)over(partition by alcohol
order by alcohol) cnt2 from geoplaces2 g join chefmozcuisine c
using (placeid))t  ;


#Let us now look at a different prospect of the data to check state-wise rating.
select * from rating_final;
select * from geoplaces2;
#Questions 5: - let’s take out the average rating of each state.
select state,state_rating from 
(select distinct state,avg(rating)over(partition by state order by state ) state_rating from
geoplaces2 g join rating_final r using(placeid))t
order by state_rating;
#Questions 6: -' Tamaulipas' Is the lowest average rated state. Quantify the reason why it is the lowest rated by providing the summary on the basis of State, 
#alcohol, and Cuisine.
select distinct state,alcohol,price,rcuisine,cnt ,avg_rating,food_rating,service_rating,state_rating from
(select distinct count(placeid)over(partition by state,rcuisine,alcohol,price) cnt,alcohol,state,price,rcuisine,avg(rating)over(partition by state,rcuisine,alcohol,price ) avg_rating,
avg(rating)over(partition by state ) state_rating,
avg(food_rating)over(partition by alcohol,state,price,rcuisine) food_rating,
avg(service_rating)over(partition by alcohol,state,price,rcuisine ) service_rating  from
geoplaces2 g join rating_final r using(placeid)
join chefmozcuisine c using(placeid) where state = 'tamaulipas') t
order by state ;

select rating , alcohol, Rcuisine , name from  chefmozcuisine join geoplaces2 using(placeid) join rating_final using(placeid) where state like '%Tamaulipas%';
select * from chefmozcuisine;
#Question 7:  - Find the average weight, food rating, and service rating of the customers who have visited KFC and tried Mexican or Italian types of cuisine,
# and also their budget level is low.
-- We encourage you to give it a try by not using joins.
select * from userprofile;
select * from rating_final;
select	* from geoplaces2;



select avg(weight)over() weight ,avg(food_rating)over() food_rating ,avg(service_rating)over()service_rating,
avg(rating)over() rating from(
select distinct userid, weight,food_rating,service_rating,rating from 
userprofile u join rating_final r using(userid) join usercuisine using(userid)
join geoplaces2  g using(placeid) 
where g.name like '%kfc%' 
and Rcuisine  in ( 'Mexican' , 'Italian') and budget like '%low%')t ;

 select userid , food_rating, service_rating, avg(weight)over () from rating_final a join 
 (select userId , weight  from userprofile where userid in
  (select userid from usercuisine where ( Rcuisine like  '%Mexican%' or  Rcuisine like '%Italian%')) and budget like '%low%') b using(userId)
   where placeid in (select placeid  from geoplaces2 where name like '%KFC%' ) ; 
   

   select distinct avg(food_rating)over(),avg(service_rating)over()
   ,avg(weight)over( ) from rating_final r join userprofile using(userid) 
   where userid in (select userid from usercuisine where Rcuisine like  '%Mexican%' or  Rcuisine like '%Italian%' 
   ) and placeid in (select placeid from geoplaces2 where name like '%kfc%') and 
   budget =any (select price from geoplaces2 where budget like '%low%');
   


select distinct avg(weight)over() weight ,avg(food_rating)over() food_rating ,avg(service_rating)over()service_rating,
avg(rating)over() rating from
(select distinct userid, weight ,food_rating,service_rating,rating
from rating_final r join  userprofile u using(userid)
 join usercuisine using(userid)  join geoplaces2  g using(placeid)
where (name like '%kfc%' )
and (Rcuisine  like  '%Mexican%' or Rcuisine like '%Italian%') and
 ( budget like '%low%' )) t ;

